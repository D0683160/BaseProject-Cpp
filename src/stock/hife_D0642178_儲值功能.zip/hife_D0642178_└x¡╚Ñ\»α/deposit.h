#ifndef DEPOSIT_H
#define DEPOSIT_H

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>

int deposit(int totalAmount);

#endif
