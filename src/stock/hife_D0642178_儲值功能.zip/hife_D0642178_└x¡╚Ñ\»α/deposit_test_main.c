#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include "deposit.h"

int main(){
	FILE *ac = NULL;
	ac = fopen("account.txt", "r");
	char a[17], s[17], cura[17], curs[17];
	int totalAmount = 0, check = 0;
	
	printf("�b�� : ");
	scanf("%s", cura);
	printf("�K�X : ");
	scanf("%s", curs);
	
	while(!feof(ac)){
		fscanf(ac, "%s %s %d", &a, &s, &totalAmount);
		if(!strcmp(cura,a)&&!strcmp(curs,s)){
			check = 1;
			break;
		}
	}
	
	if(check == 0){
		printf("�b�����s�b�αK�X���~\n");
		main();
	}
	
	totalAmount = deposit(totalAmount);
	printf("�x�Ȧ��\\!\n");
	printf("�ثe�`���B�� : ");
	printf("%d", totalAmount);
	fclose(ac);
	return 0;
}
